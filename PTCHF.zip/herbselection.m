function varargout = herbselection(varargin)
%%%%2019/10/15 writen by Li Yitao,Hong Kong Baptist University,
%%%%liyitao@hkbu.edu.hk
% HERBSELECTION MATLAB code for herbselection.fig
%      HERBSELECTION, by itself, creates a new HERBSELECTION or raises the existing
%      singleton*.
%
%      H = HERBSELECTION returns the handle to a new HERBSELECTION or the handle to
%      the existing singleton*.
%
%      HERBSELECTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HERBSELECTION.M with the given input arguments.
%
%      HERBSELECTION('Property','Value',...) creates a new HERBSELECTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before herbselection_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to herbselection_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help herbselection

% Last Modified by GUIDE v2.5 15-Oct-2019 11:49:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @herbselection_OpeningFcn, ...
                   'gui_OutputFcn',  @herbselection_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before herbselection is made visible.
function herbselection_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to herbselection (see VARARGIN)

% Choose default command line output for herbselection
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes herbselection wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = herbselection_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile('*.xlsx', 'Select your excel');
str1=[pathname,filename];
[Meta1,name]=xlsread(str1);
HH=sprintfc('%g',Meta1);
disease1=[name,HH];
Meta1=string(disease1);
handles.Meta1 = Meta1;
guidata(hObject,handles);%%%���ȫ�ֱ���
% --- Executes on button press in pushbutton1.


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ss=20;%%%%%%�ɵ��ڲ�����ȡÿһ����ҩ��ǰ����
load name.mat;
load pagerank.mat;
load herb_pinyin.mat;
disease=handles.Meta1;
%%%%%��Disease����ת��Ϊ���
exsist_gene=intersect(disease,name(:,1));
number_exsist_gene=size(exsist_gene,1);
number_genename=size(name,1);
for number1=1:number_genename
    for number2=1:number_exsist_gene
        if name(number1,1)==exsist_gene(number2,1)
            exsist_gene(number2,2)=name(number1,2);
        end
    end
end
%%%%%��ÿ��target����Ȩ�ز���һ��
number_intersect_target=size(exsist_gene,1);
for www=1:number_intersect_target
    ind=find(disease(:,1)==exsist_gene(www,1));
    exsist_gene(www,3)=disease(ind,2);
end
 exsist_gene(:,4)=str2double(exsist_gene(:,3))/max(str2double(exsist_gene(:,3)));
%%%%���exsist_gene
%%%%%warning����֪����һ���Ƿ����
value_weight=[];
sum_intersect_herb=[];
herb_name=[];
for huke=1:499
    index_intersect = pagerank(:,3) == num2str(huke);
    all_herb=pagerank(index_intersect,:);
    intersect_herb=intersect(exsist_gene(:,2),all_herb(:,2));
    hunk=size(intersect_herb,1);
    if  hunk~=0
        for hunk1=1:hunk
             ind2=find(exsist_gene(:,2)==intersect_herb(hunk1,1));
             value_weight(hunk1,1)=exsist_gene(ind2,4);
        end
        sum1=sum(value_weight,1);
        herb_name=[herb_name;huke];
        sum_intersect_herb=[sum_intersect_herb;sum1];
    end
end
all_herb_intersect=[herb_name,sum_intersect_herb];
all_herb_intersect(:,3)=all_herb_intersect(:,2)/max(all_herb_intersect(:,2));
%%%%%%%%%ÿ����ҩ��diesease�ཻ�ĸ���
% number_intersect_herb=[];
% herb_name=[];
% for number_herb=1:499
%     index_intersect = pagerank(:,3) == num2str(number_herb);
%     all_herb=pagerank(index_intersect,:);
%     intersect_herb=intersect(disease(:,2),all_herb);
%     number_herb2=size(intersect_herb,1);
%     if number_herb2~=0
%       herb_name=[herb_name;number_herb];
%       number_intersect_herb=[number_intersect_herb;number_herb2];
%     end 
% end
% all_herb_intersect=[herb_name,number_intersect_herb];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%��pagerank����ȡ����ǰ20��gene��
eliminate_herb_gene=[];
for number4=1:499
    row_index1 = pagerank(:,3) == num2str(number4);
    single_herb=pagerank(row_index1,:);
    nn=size(single_herb,1);
    if nn~=0
      if size(single_herb,1)>=ss
          topss=single_herb(1:ss,:);
          for parameter=1:ss
              topss(parameter,4)=ss+1-parameter;
          end
      elseif  size(single_herb,1)<ss
          n=size(single_herb,1);
          topss=single_herb(1:n,:);
          for parameter1=1:n
              topss(parameter1,4)=ss+1-parameter1;
          end
      end
      eliminate_herb_gene=[eliminate_herb_gene;topss];
    end
end%%%%%���eliminate_herb_gene
gene_now=intersect(exsist_gene(:,2),unique(eliminate_herb_gene(:,2)));%%%%%��ҩ�ִ��ڵİе��б�
size_gene_now=size(gene_now,1);
%%%%��ѡ��������Щ�������ҩ��
herb_include_gene=[];
for number3=1:size_gene_now
    single_gene=gene_now(number3,1);
    row_index =  eliminate_herb_gene(:,2) == single_gene;
    herb= eliminate_herb_gene(row_index,:);
    herb_include_gene=[herb_include_gene;herb];
end%%%%%���herb_include_gene
%%%%%��ѡ����Щgene��ĳ����ҩ���е�target
size_gene_now=size(gene_now,1);
prescription=[];%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����ҩ������
% for number5=1:size_gene_now
%     name_gene=gene_now(number5,1);
%     index5=herb_include_gene(:,2)==name_gene;
%     hh=herb_include_gene(index5,:);
%     size_hh=size(hh,1);
%     if size_hh==1
%         prescription=[prescription;hh(:,3)];
%     end
% end
%%%%%%�õ�ÿ����ҩ��Ȩ�غ�����
if(~isempty(prescription)) 
number_of_herb=setdiff(unique(herb_include_gene(:,3)),prescription);
else number_of_herb=unique(herb_include_gene(:,3));
end
number6=size(number_of_herb,1);
weight=[];
for num6=1:number6
    index6=herb_include_gene(:,3)==number_of_herb(num6,1);
    jjj=herb_include_gene(index6,:);
    weight(num6,1)=number_of_herb(num6,1);
    weight(num6,2)=size(jjj,1);
    fff=str2double(jjj(:,4));
    weight(num6,3)=sum(str2double(jjj(:,4)));
end
%%%%%��pagerank��Ȩ�ؽ��й�һ��
weight(:,4)=weight(:,3)/max(weight(:,3));
%%%%%������Ȩ�����
weight=sortrows(weight,1);
differ_weight=setdiff(all_herb_intersect(:,1),weight(:,1));
for master=1:size(differ_weight,1)
    ind3=find(all_herb_intersect(:,1)==differ_weight(master,1));
    all_herb_intersect(ind3,:)=[]; 
end
weight(:,5)=weight(:,4)+ all_herb_intersect(:,3);
%weight(:,3:4)=[];
%%%%%ȡ���ʵ�cut-offֵ
cut_off=size(weight,1);
number_prescription=round(cut_off*0.02);
if number_prescription<8
    number_prescription=8;
end
row_weight=sortrows(weight,-5);
prescription=row_weight(1:number_prescription,1);
size_precription=size(prescription,1);
presciption_pinyin=[];
for bv=1:499
    for jv=1:size_precription
        hk=prescription(jv,1);
        bk=str2double(herb_pinyin(bv,2));
        if hk==bk
            prescription_pinyin(jv,1)=herb_pinyin(bv,1);
        end
    end
end
set(handles.text4,'string',prescription_pinyin);
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% Hint: place code in OpeningFcn to populate axes7
% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function text4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% --- Executes during object creation, after setting all properties.
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(herbselection)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.text4,'string','')
% --- Executes during object creation, after setting all properties.
function axes17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
imshow(imread('blank.jpg'))
% Hint: place code in OpeningFcn to populate axes17


% --- Executes during object creation, after setting all properties.
function axes18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
imshow(imread('herb.jpg'))
% Hint: place code in OpeningFcn to populate axes18
